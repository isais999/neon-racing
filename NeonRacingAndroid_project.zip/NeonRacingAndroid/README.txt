NEON RACING - Proyecto Android

Este proyecto envuelve el juego HTML en una app Android usando WebView.

Cómo generar el APK:
1. Instala Android Studio en una computadora.
2. Descomprime NeonRacingAndroid.zip.
3. En Android Studio, elige Open y selecciona la carpeta NeonRacingAndroid.
4. Espera a que Gradle sincronice y que se instale el Android SDK 35 si lo solicita.
5. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
6. El APK de prueba aparecerá en app/build/outputs/apk/debug/app-debug.apk.

Nota: Este paquete es el proyecto fuente, no un APK ya compilado.
